# VG and GQA images

- Please download the gqa images from [GQA official website](https://cs.stanford.edu/people/dorarad/gqa/download.html) (20 GB).

- The Visual Genome images are contained in GQA dataset with the same image id as VG. 
Thus we only need to extract features for all GQA images.

- GQA testing images (labeled as 'nXXXXXXX') are collected from MS COCO test sets.


